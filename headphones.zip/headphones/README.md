# Headphones Website Project

A responsive website for a headphones company, working on phones, tablets, and desktops.

## Tasks
1. **Header** - Done in `0-index.html`  
2. **What We Do** - Coming soon  
3. **Our Results** - Coming soon   

## How to Run
1. Open `0-index.html` in a web browser.  
2. Resize the window to see mobile (≤480px) and desktop views.  

## Author
[karen]